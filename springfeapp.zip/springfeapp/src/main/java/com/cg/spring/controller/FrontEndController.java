package com.cg.spring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.beans.Customer;

@RestController
public class FrontEndController {

	@RequestMapping("/customers")
	public ModelAndView show()
	{
		RestTemplate rt=new RestTemplate();
		List<Customer> list=rt.getForObject("http://localhost:7070/show", ArrayList.class);
		
		return new ModelAndView("display","custom",list);
	}
}
