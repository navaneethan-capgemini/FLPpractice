package com.cg.moneyRefund.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class Order {
	
	
	private int product_id;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)	
	private int order_id;
	
	private int quantity;
	
	private String status;
	
	private String dispatchedtime;
	
	private String amount;
	
	
	

}
