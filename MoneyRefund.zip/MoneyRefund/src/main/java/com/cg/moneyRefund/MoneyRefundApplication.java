package com.cg.moneyRefund;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoneyRefundApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoneyRefundApplication.class, args);
	}
}
