package com.cg.moneyRefund.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	
	@Id
	private String customer_email;
	
	private String customer_name;
	
	private String phone_no;

	public String getCustomer_email() {
		return customer_email;
	}

	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getPhone_no() {
		return phone_no;
	}

	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}

	public Customer(String customer_email, String customer_name, String phone_no) {
		super();
		this.customer_email = customer_email;
		this.customer_name = customer_name;
		this.phone_no = phone_no;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
