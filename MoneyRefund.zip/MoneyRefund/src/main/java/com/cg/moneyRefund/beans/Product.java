package com.cg.moneyRefund.beans;

import javax.annotation.Generated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class Product {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int product_id;
	
	private String product_name;
	
	private String product_price;
	
	
	
	
	
	
	

}
