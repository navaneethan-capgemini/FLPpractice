package com.cg.spring.service;

import java.util.List;

import com.cg.spring.beans.Customer;

public interface ICustomerService {
	
	public List<Customer> showAll();
	

}
