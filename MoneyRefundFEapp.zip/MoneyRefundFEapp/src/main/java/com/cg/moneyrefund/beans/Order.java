package com.cg.moneyrefund.beans;



public class Order {

	
	
	
	private int product;
	
	
	private int order_id;
	
	
	private int quantity;
	
	
	private String status;
	
	
	private String dispatchedtime;
	
	public int getProduct() {
		return product;
	}

	public void setProduct(int product) {
		this.product = product;
	}

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDispatchedtime() {
		return dispatchedtime;
	}

	public void setDispatchedtime(String dispatchedtime) {
		this.dispatchedtime = dispatchedtime;
	}
	
	
}
