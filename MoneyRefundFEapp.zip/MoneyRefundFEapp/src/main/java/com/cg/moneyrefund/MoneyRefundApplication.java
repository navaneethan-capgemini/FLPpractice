package com.cg.moneyrefund;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.moneyrefund")
public class MoneyRefundApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoneyRefundApplication.class, args);
	}
}
