package com.cg.moneyrefund.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FrontController {
	
	

	
	@RequestMapping("/cancellation")
	public ModelAndView show(@RequestParam int product_id)
	{
		RestTemplate rt=new RestTemplate();
		String s = rt.getForObject("http://localhost:7070/show/"+product_id, String.class);
		
		if(s.equals("cancelled"))
		{
			return new ModelAndView("success","Order",s);
		}
		else
		{
		return new ModelAndView("failure","Order",s);
		}
	}
	@RequestMapping("/")
		public String sayhello()
		{
			return "form";
		}
	}

